# Meta data for GlaMBIE final dataset

## 1. Overview and dataset description

Glambie general info blablabla

How to cite: blablabla

## 2. Dataset contents

### 2.1. Dataset in hydrological years
Within subfolder "/hydrological_years"

Contains all 19 regions

**Hydrological year columns:**
- start_dates [fractional years]: start dates in decimal years of the period of change
- end_dates [fractional years]: end dates in decimal years of the period of change
- glacier_area [km^2]: area in km^2 used for a specific time period
- combined_gt [Gt]: glacier change in Gigatonnes recorded by the combined estimate between start and end dates
- combined_gt_errors [Gt]: glacier change error in Gigatonnes recorded by the combined estimate between start and end dates
- combined_mwe [m w.e.]: glacier change in meter water equivalent recorded by the combined estimate between start and end dates
- combined_mwe_errors [m w.e.]: glacier change error in meter water equivalent recorded by the combined estimate between start and end dates
- <data_group>_gt [Gt]: glacier change in Gigatonnes recorded by a data group (altimetry, gravimetry or demdiff_and_glaciological) between start and end dates
- <data_group>_gt_errors [Gt]: glacier change error in Gigatonnes recorded by a data group (altimetry, gravimetry or demdiff_and_glaciological) between start and end dates
- <data_group>_mwe [m w.e.]: glacier change in meter water equivalenmt recorded by a data group (altimetry, gravimetry or demdiff_and_glaciological) between start and end dates
- <data_group>_mwe_errors [m w.e.]: glacier change error in meter water equivalenmt recorded by a data group (altimetry, gravimetry or demdiff_and_glaciological) between start and end dates
- <data_group>_annual_variability [binary]: binary value describing if a data group provided annual variability or used the annual variability from the consensus estimate. The value "1" means that the data group provided annual variability between start and end dates


### 2.2. Dataset in calendar years

Within subfolder "/calendar_years"

Contains all 19 regions and a global time series

**Calendar year columns:**
- start_dates [fractional years]: start dates in decimal years of the period of change
- end_dates [fractional years]: end dates in decimal years of the period of change
- glacier_area [km^2]: area in km^2 used for a specific time period
- combined_gt [Gt]: glacier change in Gigatonnes recorded by the combined estimate between start and end dates
- combined_gt_errors [Gt]: glacier change error in Gigatonnes recorded by the combined estimate between start and end dates
- combined_mwe [m w.e.]: glacier change in meter water equivalent recorded by the combined estimate between start and end dates
- combined_mwe_errors [m w.e.]: glacier change error in meter water equivalent recorded by the combined estimate between start and end dates



